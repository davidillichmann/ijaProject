package ija.ija2017.interfaces;

public interface PipeItemInterface {

    int getPipeItemId();

    int getInPortId();

    int getOutPortId();
}
