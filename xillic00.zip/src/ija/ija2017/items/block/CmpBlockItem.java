///**
// *
// */
//package ija.ija2017.items.block;
//
///**
// * @author xfryct00
// *
// */
//public class CmpBlockItem extends BlockItemAbstract {
//    @Override
//    public boolean execute() {
//        return true;
//    }
//}
