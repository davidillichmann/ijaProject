IJA semestrální projekt 2017/2018

Název týmu:
	xillic00
	
Členové týmu:
	David Illichmann,	xillic00
	Tomáš Fryč,		xfryct00

Název projektu:


Použití aplikace:
	-	přeložení pomocí "ant compile" v kořenovém adresáři
	-	spuštení aplikace pomocí "ant run"
	